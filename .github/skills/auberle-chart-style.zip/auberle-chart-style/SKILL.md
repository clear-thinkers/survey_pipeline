---
name: auberle-chart-style
description: >
  Apply the Auberle / 412 Youth Zone report visualization style whenever the user asks
  to make a chart, table, or data visual "in Auberle style", "in report style", or
  "consistent with the Youth Zone report". Also trigger when the user says "use our
  house style", "reuse the template", or "same style as before" in the context of
  data visualization. Produces polished HTML/CSS widgets and exportable PNG files
  that match the organization's established visual identity.
---

# Auberle Report Visualization Style Guide

Use this skill to produce charts, tables, and data visuals that match the design
language established in the 412 Youth Zone annual survey reports.

---

## Core Design Principles

- **White background** — always `background: #fff`, never transparent or colored containers
- **Clean and minimal** — no gradients, no shadows, no decorative effects
- **Flat, editorial feel** — generous whitespace, thin borders, restrained color use
- **Font stack** — `'Segoe UI', Arial, sans-serif` (system sans-serif, not display fonts)
- **Two font weights only** — 400 (body) and 600–700 (labels, headings, highlighted values)

---

## Color Palette

Use color sparingly and only to encode meaning.

| Role              | Hex       | Usage                                      |
|-------------------|-----------|--------------------------------------------|
| **Blue**          | `#185FA5` | Highest value, positive highlight, primary accent |
| **Orange**        | `#C2600A` | Lowest value, cautionary highlight         |
| **Dark text**     | `#111`    | Title, current-period values               |
| **Body text**     | `#333`    | Table cell values, general data            |
| **Muted text**    | `#888` / `#999` | Column headers, n-counts, footnotes  |
| **Border light**  | `#ebebeb` | Row dividers                               |
| **Border mid**    | `#e0e0e0` | Section dividers                           |
| **Border strong** | `#111`    | Header underline (2px)                     |
| **Sparkline line**| `#bbb`    | Trend line stroke                          |
| **Dot neutral**   | `#ccc` / `#555` | Non-highlighted sparkline dots       |

**Rule:** Only the global min and max within a row (or dataset) get color. Everything else stays neutral.

---

## Typography

| Element              | Size  | Weight | Color   |
|----------------------|-------|--------|---------|
| Table title          | 13px  | 700    | `#111`  |
| Column header (upper)| 11px  | 500    | `#888`, uppercase, letter-spacing 0.04em |
| Column header (lower)| 12px  | 500–600| `#444`  |
| n-count row          | 11px  | 400    | `#999`  |
| Data cells           | 13–14px| 400   | `#333`  |
| Current-period cells | 13–14px| 500–600| `#111` |
| Highlighted min/max  | same  | 600–700| blue / orange |
| Footnote             | 11–12px| 400   | `#aaa`  |

**Title casing:** Title Case for chart/table titles (e.g. "Satisfaction Ratings for Youth Coaches Over Time").
All other labels use sentence case.

---

## Table Structure

### Header pattern for multi-period tables
```
[ Row label col ]  [ Merged header: "% Often or all of the time"  ]  [ Trend ]
[ "My coach…"   ]  [ Sep-19 | Mar-22 | Feb-23 | Feb-24 | Feb-25 | Mar-26 ]  [ Trend ]
```
- The spanning label ("% Often or all of the time") uses `colspan` to merge across all data columns
- The sub-header row has `border-bottom: 2px solid #111`
- The n-count row sits between the header and data rows, separated by `border-bottom: 1px solid #e0e0e0`
- Data rows use `border-bottom: 0.5px solid #ebebeb`; last row has no border

### Color coding rule
```js
const mx = Math.max(...rowData);
const mn = Math.min(...rowData);
// Apply blue to mx cells, orange to mn cells, nothing to the rest
```
CSS must declare `val-max` and `val-min` AFTER `col-cur` so min/max always win specificity ties.

---

## Sparkline Trend Lines

Include a sparkline column in multi-period tables. Render using HTML Canvas (60×28–32px).

```js
// Standard sparkline pattern
const W=60, H=28, pad=4;
const lo = Math.min(...data) - 2;
const hi = Math.max(...data) + 2;
const xs = data.map((_,i) => pad + i*(W-2*pad)/(data.length-1));
const ys = data.map(v => H - pad - (v-lo)/(hi-lo)*(H-2*pad));

// Line
ctx.strokeStyle = '#bbb'; ctx.lineWidth = 1.5;

// Dots: 1.8px radius for history, 3.5px for last point
// Last dot color: blue if max, orange if min, #555 otherwise
// History dot color: blue if max, orange if min, #ccc otherwise
```

---

## Chart Types & When to Use

| Type | Use case | Key style notes |
|------|----------|-----------------|
| **Data table + sparklines** | Multi-period longitudinal data (coach ratings, banking trends) | See table structure above |
| **Simple bar chart** | Single-period comparisons (job barriers, reasons for leaving) | Horizontal bars, `#185FA5` fill, `#ebebeb` gridlines only, no axis borders |
| **Grouped bar chart** | Comparisons across 2–3 subgroups | Blue + orange as the two primary group colors |
| **Donut / pie** | Part-of-whole (housing status, license status) | Blue dominant slice, orange secondary, gray for remaining |
| **Stacked bar** | Composition over time or across groups | Blue + orange + `#bbb` neutral |

---

## Export

When the user requests a PNG/JPEG export:
1. Write the visualization to a standalone HTML file with full `<!DOCTYPE html>` boilerplate
2. Use `wkhtmltoimage --width 820 --quality 95 --javascript-delay 500`
3. Output to `/mnt/user-data/outputs/`
4. Present with `present_files`

```bash
wkhtmltoimage --width 820 --quality 95 --javascript-delay 500 input.html output.png
```

---

## Quick-Reference Prompt Pattern

When a user says:

> "Make a [chart type] of [data] in Auberle style"

Apply this checklist:
- [ ] White background
- [ ] Title in Title Case, bold, `#111`, 13px
- [ ] Merged span header if multi-period
- [ ] Blue = max, orange = min, nothing else colored
- [ ] Sparkline column if multi-period (Canvas, 60×28)
- [ ] Footnote in `#aaa`, 11–12px
- [ ] CSS: declare `col-cur` before `val-min`/`val-max` so highlights always win
- [ ] Export PNG at 820px wide if requested

---

## Example Invocations

- *"Make a horizontal bar chart of job barriers in Auberle style"*
- *"Make a housing status donut chart in Auberle style"*
- *"Same style as before — employment by age grouped bars"*
- *"Rebuild the banking table with sparklines, Auberle style, export PNG"*
